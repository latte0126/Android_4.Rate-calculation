package com.example.a4ratecalculation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Calculation(View view) {
        DecimalFormat nf = new DecimalFormat("0");
        EditText distance = (EditText)findViewById(R.id.editTextTextPersonName);
        EditText dollar = (EditText)findViewById(R.id.editTextTextPersonName2);
        EditText total = (EditText)findViewById(R.id.editTextTextPersonName3);
        TextView price = (TextView) findViewById(R.id.textView6);
        double distance1 = Double.parseDouble(distance.getText().toString());
        double dollar1 = Double.parseDouble(dollar.getText().toString());
        double total1 = Double.parseDouble(total.getText().toString());
        double price1 =Math.ceil(75+(total1/distance1)*dollar1);
        price.setText(price1+"$");

    }
}